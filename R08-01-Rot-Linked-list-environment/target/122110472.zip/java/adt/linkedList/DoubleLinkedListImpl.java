package adt.linkedList;

public class DoubleLinkedListImpl<T> extends SingleLinkedListImpl<T> implements
		DoubleLinkedList<T> {

	protected DoubleLinkedListNode<T> last;

	@Override
	public void insertFirst(T element) {
		if (element != null) {
			DoubleLinkedListNode<T> newHead = new DoubleLinkedListNode<T>();
			newHead.setData(element);
			newHead.setNext(getHead());
			newHead.setPrevious(new DoubleLinkedListNode<>());
			((DoubleLinkedListNode<T>) getHead()).setPrevious(newHead);

			if (getHead().isNIL()) {
				setLast(newHead);
			}
			setHead(newHead);
		}
	}

	@Override
	public void removeFirst() {
		if (!isEmpty()) {
			setHead(getHead().getNext());

			if (isEmpty()) {
				setLast((DoubleLinkedListNode<T>) getHead());
			}
			((DoubleLinkedListNode<T>) getHead()).setPrevious(new DoubleLinkedListNode<>());
		}
	}
	
	@Override
	public void removeLast() {
		if (!isEmpty() && !getLast().isNIL()) {
			setLast(getLast().getPrevious());

			if (getLast().isNIL()) {
				setHead((DoubleLinkedListNode<T>) getLast());
			} else {
				((DoubleLinkedListNode<T>) getLast()).setNext(new DoubleLinkedListNode<>());
			}
		}
	}

	public DoubleLinkedListNode<T> getLast() {
		return last;
	}

	public void setLast(DoubleLinkedListNode<T> last) {
		this.last = last;
	}

}
